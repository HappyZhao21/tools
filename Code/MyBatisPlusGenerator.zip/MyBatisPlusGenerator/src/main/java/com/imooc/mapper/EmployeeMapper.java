package com.imooc.mapper;

import com.imooc.entity.Employee;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Bean
 * @since 2018-07-02
 */
public interface EmployeeMapper extends BaseMapper<Employee> {

}
