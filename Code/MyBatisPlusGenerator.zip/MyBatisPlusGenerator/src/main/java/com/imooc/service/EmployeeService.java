package com.imooc.service;

import com.imooc.entity.Employee;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Bean
 * @since 2018-07-02
 */
public interface EmployeeService extends IService<Employee> {

}
